import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-member-dashboard',
  templateUrl: './member-dashboard.component.html',
  styleUrls: ['./member-dashboard.component.scss']
})
export class MemberDashboardComponent implements OnInit {
  model = {
    left: true,
    middle: false,
    right: false
  };
  constructor(private userService: UserService, private router: Router) {

  }

  ngOnInit(): void {
  }

  getUsers() {
    return this.userService.getUsers();
  }

}
