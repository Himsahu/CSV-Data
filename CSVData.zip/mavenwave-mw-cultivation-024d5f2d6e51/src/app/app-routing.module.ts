import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {MemberDashboardComponent} from './member/member-dashboard/member-dashboard.component';
import {AdminDashboardComponent} from './admin/admin-dashboard/admin-dashboard.component';
import { DataComponent } from './data/data.component';


const routes: Routes = [
  {path: '', component: AdminDashboardComponent},
  {path: 'admin-dashboard', component: AdminDashboardComponent},
  {path: 'member-dashboard', component: MemberDashboardComponent},
  {path: 'data-dashboard', component: DataComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
