import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {

  listOfSkills = [
    { name: '.Net 4.5', value: '.Net 4.5' },
    { name: 'Java', value: 'Java' },
    { name: 'Python', value: '.Net 4.5' },
    { name: '7 Studio', value: '7 Studio' },
    { name: 'Adobe Xd', value: 'Adobe Xd' },
    { name: 'Big Quesry', value: 'Big Quesry' }
  ];
  constructor(private router: Router) { }


  ngOnInit(): void {
  }


}
