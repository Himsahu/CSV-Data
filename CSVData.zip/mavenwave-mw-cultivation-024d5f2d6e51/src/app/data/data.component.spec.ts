import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataComponent } from './data.component';
import {ReactiveFormsModule} from '@angular/forms';

describe('DataComponent', () => {
  let component: DataComponent;
  let fixture: ComponentFixture<DataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule],
      declarations: [ DataComponent ]

    })
    .compileComponents();
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(DataComponent);
    let app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'CSV Import'`, () => {
    const fixture = TestBed.createComponent(DataComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('CSV Import');
  });
});
